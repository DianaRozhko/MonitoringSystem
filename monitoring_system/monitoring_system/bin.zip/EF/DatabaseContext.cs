﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using DAL.Entities;
using DAL.Repositories.Impl;
using Microsoft.EntityFrameworkCore;

namespace DAL.EF
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options)
            : base(options)
        {
        }

        // DbSet для кожної сутності
        public DbSet<Data> Data { get; set; }
        public DbSet<Report> Reports { get; set; }
        public DbSet<Scientist> Scientists { get; set; }
        public DbSet<Sensor> Sensors { get; set; }

        // Конфігурація моделі
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Налаштування для Data
            modelBuilder.Entity<Data>()
                .HasKey(d => d.Id);

            modelBuilder.Entity<Data>()
                .HasOne(d => d.Report)
                .WithMany(r => r.Data)
                .HasForeignKey(d => d.ReportId);

            // Налаштування для Report
            modelBuilder.Entity<Report>()
                .HasKey(r => r.Id);

            // Налаштування для Scientist
            modelBuilder.Entity<Scientist>()
                .HasKey(s => s.Id);

            // Налаштування для Sensor
            modelBuilder.Entity<Sensor>()
                .HasKey(s => s.Id);

            modelBuilder.Entity<Sensor>()
                .HasMany(s => s.Data)
                .WithOne(d => d.Sensor)
                .HasForeignKey(d => d.SensorId);
        }
    }
}
